package com.olympic.cis143.m04.student.tacotruck.set;

import com.olympic.cis143.m04.student.tacotruck.Orders;
import com.olympic.cis143.m04.student.tacotruck.TacoImpl;

import java.util.LinkedList;

import java.util.Queue;

public class OrdersSetImpl implements Orders 
{
	// Queue data strcuture to store FIFO orders
	Queue<TacoImpl> orders = new LinkedList<TacoImpl>(); 
	
	@Override
	
	public void addOrder(TacoImpl tacoOrder) 
	{
		// add the order to the end of list
		orders.add(tacoOrder);
	}
	@Override
	public boolean hasNext() 
	{
		// if queue has any order
		return orders.size() > 0;
	}
	@Override

	public TacoImpl closeNextOrder() 
		{
		// Remove the first order from the queue
		return orders.remove();
		}
	
	@Override
	
	public int howManyOrders()
		{
		// Return total number of orders
		return orders.size();
		}

}
