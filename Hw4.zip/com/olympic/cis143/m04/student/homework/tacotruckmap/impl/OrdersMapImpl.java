package com.olympic.cis143.m04.student.homework.tacotruckmap.impl;

import com.olympic.cis143.m04.student.homework.tacotruckmap.OrderDoesNotExistException;
import com.olympic.cis143.m04.student.homework.tacotruckmap.Orders;
import com.olympic.cis143.m04.student.homework.tacotruckmap.TacoImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrdersMapImpl implements Orders {

    HashMap<String, ArrayList<TacoImpl>> map = new HashMap<>();

    @Override
    public void createOrder(final String orderid) {
        if (!map.containsKey(orderid)){
            map.put(orderid, new ArrayList<>());
        }
    }

    @Override
    public void addTacoToOrder(final String orderid, final TacoImpl taco) throws OrderDoesNotExistException {
        if (map.get(orderid) == null) throw new OrderDoesNotExistException(orderid);
        map.get(orderid).add(taco);
    }

    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public List closeOrder(final String orderid) throws OrderDoesNotExistException {
        if (map.get(orderid) == null) throw new OrderDoesNotExistException(orderid);
        List closing = map.get(orderid);
        map.remove(orderid);
        return closing;
    }

    @Override
    public int howManyOrders() {
        return map.size();
    }

    @Override
    public List getListOfOrders(final String orderid) throws OrderDoesNotExistException {
        if (map.get(orderid) == null) throw new OrderDoesNotExistException(orderid);
        return map.get(orderid);
    }
}

